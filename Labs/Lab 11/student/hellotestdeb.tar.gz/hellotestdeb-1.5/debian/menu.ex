?package(hellotestdeb):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="hellotestdeb" command="/usr/bin/hellotestdeb"
