# Defaults for hellotestdeb initscript
# sourced by /etc/init.d/hellotestdeb
# installed at /etc/default/hellotestdeb by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
