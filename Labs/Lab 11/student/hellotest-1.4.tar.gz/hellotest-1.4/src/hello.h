#include <iostream>

using namespace std;

#ifndef HELLO
#define HELLO "Hello World"
#endif
