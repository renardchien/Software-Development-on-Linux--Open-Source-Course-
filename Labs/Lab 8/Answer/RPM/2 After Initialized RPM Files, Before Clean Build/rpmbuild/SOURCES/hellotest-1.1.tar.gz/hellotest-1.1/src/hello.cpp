#include <iostream>
#include "hello.h"

using namespace std;

int main()
{
	cout << HELLO << endl;
	return 0;
}
