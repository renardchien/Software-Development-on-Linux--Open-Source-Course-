# Defaults for hellotest initscript
# sourced by /etc/init.d/hellotest
# installed at /etc/default/hellotest by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
