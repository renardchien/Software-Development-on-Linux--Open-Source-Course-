?package(hellotest):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="hellotest" command="/usr/bin/hellotest"
